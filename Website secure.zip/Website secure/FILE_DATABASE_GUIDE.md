# File-Based Database System Guide

## Overview

The application now uses a **standalone file-based database system** instead of MySQL. All data is stored in JSON files within the `db/` directory, making it completely portable and requiring no database server setup.

## Directory Structure

```
db/
├── FileDatabase.php    # Main database class with all CRUD operations
├── init.php            # Auto-initialization script (creates default users)
├── README.md           # Database documentation
├── .gitignore          # Ignores data files (keeps code files)
├── users/              # User data (one JSON file per user)
│   ├── admin_001.json
│   ├── user_001.json
│   └── ...
├── files/              # File metadata (one JSON file per file)
│   ├── [file_id].json
│   └── ...
├── sessions/           # Active user sessions
│   └── [session_id].json
├── audit_logs/         # Activity and security logs
│   └── [log_id].json
└── file_shares/        # File sharing records
    └── [share_id].json
```

## Features

✅ **No Database Server Required** - Works with just PHP  
✅ **Portable** - Easy to backup (just copy the `db/` folder)  
✅ **Simple Structure** - Each record is a separate JSON file  
✅ **Automatic Initialization** - Creates default users on first run  
✅ **Compatible API** - Drop-in replacement for MySQL operations  

## Default Users

On first run, the system automatically creates:

1. **Admin User**
   - Email: `admin@securefileshare.com`
   - Password: `admin123`
   - Role: Admin (all permissions)

2. **Regular User**
   - Email: `user@securefileshare.com`
   - Password: `user123`
   - Role: User (upload, download, share)

3. **Viewer User**
   - Email: `viewer@securefileshare.com`
   - Password: `viewer123`
   - Role: Viewer (download only)

## Usage

The file database is automatically initialized when `config.php` is loaded. No setup required!

### Accessing the Database

```php
require_once 'config.php';
$db = getDatabase();

// Get all users
$users = $db->getAllUsers();

// Get user by email
$user = $db->getUserByEmail('admin@securefileshare.com');

// Create a user
$userId = $db->createUser([
    'email' => 'newuser@example.com',
    'password_hash' => password_hash('password', PASSWORD_DEFAULT),
    'first_name' => 'John',
    'last_name' => 'Doe',
    'role' => 'user',
    'is_active' => true,
    'permissions' => ['file.upload', 'file.download']
]);
```

## Backup & Restore

### Backup
Simply copy the entire `db/` directory:
```bash
cp -r db/ db_backup_$(date +%Y%m%d)/
```

### Restore
Replace the `db/` directory with your backup:
```bash
rm -rf db/
cp -r db_backup_20240101/ db/
```

## Security

- All passwords are hashed using `password_hash()` (bcrypt)
- File permissions are set to 0755
- Sensitive data is never stored in plain text
- Each record is isolated in its own file

## Migration from MySQL

If you have existing MySQL data:

1. Export your MySQL data to JSON format
2. Place JSON files in the appropriate `db/` subdirectories
3. Follow the naming convention: `{id}.json`

## File Format Examples

### User File (`db/users/admin_001.json`)
```json
{
    "id": "admin_001",
    "email": "admin@securefileshare.com",
    "password_hash": "$2y$10$...",
    "first_name": "Admin",
    "last_name": "User",
    "role": "admin",
    "is_active": true,
    "permissions": ["all"],
    "created_at": "2024-01-01 12:00:00",
    "updated_at": "2024-01-01 12:00:00"
}
```

### File Metadata (`db/files/{file_id}.json`)
```json
{
    "file_id": "abc123...",
    "name": "document.pdf",
    "size": 1024000,
    "file_path": "storage/encrypted/abc123.enc",
    "uploaded_by": "user_001",
    "uploaded_at": 1704110400,
    "expires_at": 1704196800,
    "encrypted": true,
    "download_count": 5
}
```

## Troubleshooting

### Database Not Initializing
- Check that `db/` directory is writable (chmod 755)
- Ensure PHP has write permissions

### Users Not Loading
- Check `db/users/` directory exists
- Verify JSON files are valid
- Check file permissions

### Files Not Saving
- Verify `storage/encrypted/` directory exists and is writable
- Check disk space

## Performance Notes

- File-based database is suitable for small to medium deployments
- For high-traffic applications, consider migrating to MySQL/PostgreSQL
- JSON files are read/written on each operation (no caching by default)





