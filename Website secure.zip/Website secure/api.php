<?php
session_start();

// Load configuration first
require_once __DIR__ . '/config.php';

// Simple JWT-like token system
function generateToken($user) {
    $header = base64_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
    $payload = base64_encode(json_encode([
        'user_id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['role'],
        'permissions' => $user['permissions'],
        'exp' => time() + (defined('JWT_EXPIRY') ? JWT_EXPIRY : 3600)
    ]));
    $secret = defined('JWT_SECRET') ? JWT_SECRET : 'secure_jwt_secret_key';
    $signature = base64_encode(hash_hmac('sha256', $header . '.' . $payload, $secret, true));
    return $header . '.' . $payload . '.' . $signature;
}

function validateToken($token) {
    // Ensure config is loaded
    if (!defined('JWT_SECRET')) {
        require_once __DIR__ . '/config.php';
    }
    
    if (empty($token)) {
        return false;
    }
    
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }

    $header = $parts[0];
    $payload = $parts[1];
    $signature = $parts[2];

    // Use the same secret as generateToken
    $secret = defined('JWT_SECRET') ? JWT_SECRET : 'secure_jwt_secret_key';
    $expectedSignature = base64_encode(hash_hmac('sha256', $header . '.' . $payload, $secret, true));
    
    if (!hash_equals($signature, $expectedSignature)) {
        return false;
    }

    $payloadData = json_decode(base64_decode($payload), true);
    if (!$payloadData) {
        return false;
    }
    
    // Check expiration
    if (isset($payloadData['exp']) && $payloadData['exp'] < time()) {
        return false;
    }

    return $payloadData;
}

// Simple encryption functions
function encryptData($data, $key) {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . $encrypted);
}

function decryptData($encryptedData, $key) {
    $data = base64_decode($encryptedData);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
}

// Log activity to file database
function logActivity($eventType, $action, $fileId = null, $fileName = null, $userId = null, $success = true, $description = null, $riskLevel = 'low') {
    require_once __DIR__ . '/config.php';
    $db = getDatabase();
    
    // Get user email if available
    $userEmail = 'Unknown User';
    if ($userId) {
        $user = $db->getUserById($userId);
        if ($user && isset($user['email'])) {
            $userEmail = $user['email'];
        }
    }
    
    $logData = [
        'event_type' => $eventType,
        'action' => $action,
        'file_id' => $fileId,
        'file_name' => $fileName ?? 'Unknown File',
        'user_id' => $userId,
        'user_email' => $userEmail,
        'success' => $success,
        'description' => $description,
        'risk_level' => $riskLevel,
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'session_id' => session_id()
    ];
    
    $db->createAuditLog($logData);
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    switch ($_POST['action']) {
        case 'login':
            require_once __DIR__ . '/config.php';
            $db = getDatabase();
            
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = trim($_POST['role'] ?? '');

            if (empty($email) || empty($password) || empty($role)) {
                echo json_encode(['success' => false, 'message' => 'Email, password, and role are required']);
                exit;
            }

            // Validate role
            if (!in_array($role, ['admin', 'user'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid role selected']);
                exit;
            }

            // Get user from file database
            $user = $db->getUserByEmail($email);
            
            // Check if user exists, password is correct, AND role matches
            if ($user && isset($user['password_hash']) && password_verify($password, $user['password_hash'])) {
                // Check if role matches
                $userRole = $user['role'] ?? 'user';
                if ($userRole !== $role) {
                    // Log failed login attempt due to role mismatch
                    logActivity('authentication', 'login', null, null, $user['id'] ?? null, false, "Failed login attempt - role mismatch for: {$email} (Expected: {$role}, Actual: {$userRole})", 'high');
                    echo json_encode(['success' => false, 'message' => 'Invalid email, password, or role. Please check your credentials and try again.']);
                    exit;
                }
                
                // Check if user is active
                if (isset($user['is_active']) && !$user['is_active']) {
                    logActivity('authentication', 'login', null, null, $user['id'], false, "Login attempt for inactive account: {$email}", 'high');
                    echo json_encode(['success' => false, 'message' => 'Account is inactive. Please contact administrator.']);
                    exit;
                }
                
                // Update last login
                $user['last_login'] = date('Y-m-d H:i:s');
                $user['failed_login_attempts'] = 0;
                $db->updateUser($user['id'], $user);
                
                // Generate token
                $token = generateToken($user);
                $_SESSION['user_token'] = $token;
                $_SESSION['user_id'] = $user['id'];
                
                // Create session in database
                $db->createSession([
                    'session_id' => session_id(),
                    'user_id' => $user['id'],
                    'token_hash' => hash('sha256', $token),
                    'expires_at' => date('Y-m-d H:i:s', time() + 3600)
                ]);

                // Log successful login
                logActivity('authentication', 'login', null, null, $user['id'], true, "User logged in successfully: {$email} (Role: {$role})", 'low');

                $fullName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
                echo json_encode([
                    'success' => true,
                    'token' => $token,
                    'user' => [
                        'id' => $user['id'],
                        'name' => $fullName ?: $email,
                        'first_name' => $user['first_name'] ?? '',
                        'last_name' => $user['last_name'] ?? '',
                        'email' => $email,
                        'role' => $user['role'] ?? 'user',
                        'permissions' => $user['permissions'] ?? [],
                        'two_factor_enabled' => $user['two_factor_enabled'] ?? false
                    ],
                    'message' => 'Login successful'
                ]);
            } else {
                // Update failed login attempts
                if ($user) {
                    $user['failed_login_attempts'] = ($user['failed_login_attempts'] ?? 0) + 1;
                    $user['last_login_attempt'] = date('Y-m-d H:i:s');
                    $db->updateUser($user['id'], $user);
                }
                
                // Log failed login attempt
                logActivity('authentication', 'login', null, null, $user['id'] ?? null, false, "Failed login attempt for: {$email} (Invalid email or password)", 'high');
                
                echo json_encode(['success' => false, 'message' => 'Invalid email, password, or role. Please check your credentials and try again.']);
            }
            exit;

        case 'signup':
            require_once __DIR__ . '/config.php';
            $db = getDatabase();
            
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $firstName = trim($_POST['first_name'] ?? '');
            $lastName = trim($_POST['last_name'] ?? '');
            $role = trim($_POST['role'] ?? 'user');

            if (empty($email) || empty($password) || empty($firstName) || empty($lastName)) {
                echo json_encode(['success' => false, 'message' => 'All fields are required']);
                exit;
            }

            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode(['success' => false, 'message' => 'Invalid email format']);
                exit;
            }

            // Validate password strength
            if (strlen($password) < 6) {
                echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
                exit;
            }

            // Validate role
            if (!in_array($role, ['admin', 'user'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid role selected']);
                exit;
            }

            try {
                // Check if user already exists
                $existingUser = $db->getUserByEmail($email);
                if ($existingUser) {
                    echo json_encode(['success' => false, 'message' => 'Email already registered']);
                    exit;
                }

                // Hash password
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                // Set permissions based on role
                $permissions = [];
                if ($role === 'admin') {
                    $permissions = ['all'];
                } else {
                    $permissions = ['file.upload', 'file.download', 'file.share'];
                }

                // Create user
                $userId = $db->createUser([
                    'email' => $email,
                    'password_hash' => $passwordHash,
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'role' => $role,
                    'is_active' => true,
                    'permissions' => $permissions,
                    'two_factor_enabled' => false,
                    'failed_login_attempts' => 0
                ]);

                logActivity('authentication', 'signup', null, null, $userId, true, "New user registered: {$email} (Role: {$role})", 'low');

                echo json_encode([
                    'success' => true,
                    'message' => 'Account created successfully! You can now login.',
                    'user_id' => $userId
                ]);
            } catch (Exception $e) {
                error_log("Signup error: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
            }
            exit;

        case 'check_email':
            $db = getDatabase();
            
            $email = trim($_POST['email'] ?? '');
            
            if (empty($email)) {
                echo json_encode(['success' => false, 'message' => 'Email is required', 'exists' => false]);
                exit;
            }
            
            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode(['success' => false, 'message' => 'Invalid email format', 'exists' => false]);
                exit;
            }
            
            // Check if email exists in database
            $user = $db->getUserByEmail($email);
            
            if ($user) {
                echo json_encode([
                    'success' => true,
                    'exists' => true,
                    'message' => 'Email found. You can now reset your password.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'exists' => false,
                    'message' => 'Email address not found in our system'
                ]);
            }
            exit;

        case 'reset_password':
            $db = getDatabase();
            
            $email = trim($_POST['email'] ?? '');
            $newPassword = $_POST['new_password'] ?? '';
            
            if (empty($email) || empty($newPassword)) {
                echo json_encode(['success' => false, 'message' => 'Email and password are required']);
                exit;
            }
            
            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode(['success' => false, 'message' => 'Invalid email format']);
                exit;
            }
            
            // Validate password strength
            if (strlen($newPassword) < 6) {
                echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
                exit;
            }
            
            // Get user by email
            $user = $db->getUserByEmail($email);
            
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'Email address not found']);
                exit;
            }
            
            // Hash the new password
            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Update user password
            $updateData = [
                'password_hash' => $passwordHash,
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            // Preserve other user data
            $updateData['email'] = $user['email'];
            $updateData['first_name'] = $user['first_name'] ?? '';
            $updateData['last_name'] = $user['last_name'] ?? '';
            $updateData['role'] = $user['role'] ?? 'user';
            $updateData['is_active'] = $user['is_active'] ?? true;
            $updateData['permissions'] = $user['permissions'] ?? [];
            $updateData['two_factor_enabled'] = $user['two_factor_enabled'] ?? false;
            $updateData['failed_login_attempts'] = 0; // Reset failed attempts
            $updateData['created_at'] = $user['created_at'] ?? date('Y-m-d H:i:s');
            
            $success = $db->updateUser($user['id'], $updateData);
            
            if ($success) {
                // Log password reset activity
                logActivity('authentication', 'password_reset', null, null, $user['id'], true, "Password reset for user: {$email}", 'medium');
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Password reset successfully. You can now login with your new password.'
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to reset password. Please try again.']);
            }
            exit;

        case 'upload':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            $permissions = $user['permissions'] ?? [];
            if (!in_array('file.upload', $permissions) && !in_array('all', $permissions)) {
                echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                exit;
            }

            if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                $fileId = bin2hex(random_bytes(16));
                
                // Get custom file name if provided, otherwise use original
                $customFileName = $_POST['custom_file_name'] ?? '';
                $originalFileName = $_FILES['file']['name'];
                $fileName = !empty($customFileName) ? $customFileName : $originalFileName;
                
                // Get password protection if enabled
                $filePassword = $_POST['file_password'] ?? null;
                $hasPassword = !empty($filePassword);
                
                // Hash password if provided (for secure storage)
                $passwordHash = null;
                if ($hasPassword) {
                    $passwordHash = password_hash($filePassword, PASSWORD_DEFAULT);
                }
                
                // Get download limit
                $downloadLimit = isset($_POST['download_limit']) ? intval($_POST['download_limit']) : null;
                if ($downloadLimit !== null && ($downloadLimit < 1 || $downloadLimit > 999)) {
                    $downloadLimit = null; // Invalid value, ignore it
                }
                
                // Save original file to uploads directory (pending encryption)
                $uploadPath = UPLOAD_PATH;
                if (!file_exists($uploadPath)) {
                    mkdir($uploadPath, 0755, true);
                }
                $originalFilePath = $uploadPath . $fileId . '_' . basename($originalFileName);
                move_uploaded_file($_FILES['file']['tmp_name'], $originalFilePath);
                
                // Store file metadata in database with status "pending"
                $fileData = [
                    'file_id' => $fileId,
                    'name' => $fileName,
                    'original_name' => $originalFileName, // Keep original for reference
                    'size' => $_FILES['file']['size'],
                    'file_path' => $originalFilePath,
                    'encrypted_path' => null, // Will be set after admin encryption
                    'uploaded_by' => $user['id'],
                    'uploaded_at' => time(),
                    'status' => 'pending', // pending, encrypted, ready
                    'encrypted' => false,
                    'encrypted_at' => null,
                    'encrypted_by' => null,
                    'shared_with' => []
                ];
                
                // Add password protection if enabled
                if ($hasPassword && $passwordHash) {
                    $fileData['password_hash'] = $passwordHash;
                    $fileData['password_protected'] = true;
                }
                
                // Add download limit if set
                if ($downloadLimit !== null) {
                    $fileData['download_limit'] = $downloadLimit;
                    $fileData['download_count'] = 0; // Initialize download counter
                }
                
                $db->createFile($fileData);

                // Log upload activity
                $logMessage = "File uploaded and waiting for admin encryption: {$fileName}";
                if ($hasPassword) {
                    $logMessage .= " (Password protected)";
                }
                if ($downloadLimit !== null) {
                    $logMessage .= " (Download limit: {$downloadLimit})";
                }
                logActivity('file_upload', 'upload', $fileId, $fileName, $user['id'], true, $logMessage, 'low');

                echo json_encode([
                    'success' => true,
                    'file_id' => $fileId,
                    'message' => 'File uploaded successfully. Waiting for admin encryption.',
                    'file_info' => [
                        'name' => $fileName,
                        'size' => $_FILES['file']['size'],
                        'status' => 'pending'
                    ]
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'File upload failed']);
            }
            exit;

        case 'download':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $fileId = $_POST['file_id'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Get file from database
            $file = $db->getFileById($fileId);
            
            if (!$file) {
                // Log file not found
                logActivity('file_access', 'download', $fileId, 'Unknown File', $user['id'], false, "File not found: {$fileId}", 'medium');
                echo json_encode(['success' => false, 'message' => 'File not found']);
                exit;
            }
            
            // Check if file is encrypted and ready for download
            $fileStatus = $file['status'] ?? 'pending';
            if ($fileStatus !== 'ready' && $fileStatus !== 'encrypted') {
                logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], false, "File not ready for download (status: {$fileStatus}): {$file['name']}", 'medium');
                echo json_encode(['success' => false, 'message' => 'File is still being processed. Please wait for admin encryption.']);
                exit;
            }
            
            // Check if user has access (owner or admin)
            $permissions = $user['permissions'] ?? [];
            if ($file['uploaded_by'] !== $user['id'] && !in_array('all', $permissions)) {
                // Check if file is shared with user
                $shares = $db->getFileShares($fileId, $user['id']);
                if (empty($shares)) {
                    logActivity('access_denied', 'download', $fileId, $file['name'], $user['id'], false, "Access denied: No permission to download {$file['name']}", 'high');
                    echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                    exit;
                }
            }

            // Check if file has expired (only if expiry is set)
            $expiresAt = isset($file['expires_at']) ? (is_numeric($file['expires_at']) ? $file['expires_at'] : strtotime($file['expires_at'])) : null;
            if ($expiresAt !== null && $expiresAt < time()) {
                // Log expired file access
                logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], false, "File expired: {$file['name']}", 'high');
                echo json_encode(['success' => false, 'message' => 'File has expired']);
                exit;
            }

            // Check download limit
            if (isset($file['download_limit']) && $file['download_limit'] !== null) {
                $downloadCount = isset($file['download_count']) ? intval($file['download_count']) : 0;
                if ($downloadCount >= $file['download_limit']) {
                    logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], false, "Download limit reached ({$downloadCount}/{$file['download_limit']}): {$file['name']}", 'medium');
                    echo json_encode(['success' => false, 'message' => 'Download limit has been reached for this file']);
                    exit;
                }
            }
            
            // Check password protection (if enabled, require password verification)
            if (isset($file['password_protected']) && $file['password_protected'] && isset($file['password_hash'])) {
                $providedPassword = $_POST['file_password'] ?? '';
                
                if (empty($providedPassword)) {
                    logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], false, "Password required for download: {$file['name']}", 'medium');
                    echo json_encode([
                        'success' => false, 
                        'message' => 'This file is password protected. Please provide the password.',
                        'requires_password' => true
                    ]);
                    exit;
                }
                
                // Verify password
                if (!password_verify($providedPassword, $file['password_hash'])) {
                    logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], false, "Incorrect password provided for download: {$file['name']}", 'high');
                    echo json_encode([
                        'success' => false, 
                        'message' => 'Incorrect password. Please try again.',
                        'requires_password' => true
                    ]);
                    exit;
                }
                
                // Password is correct, log successful access
                logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], true, "Password-protected file accessed with correct password: {$file['name']}", 'low');
            }

            // Check user permissions
            $permissions = $user['permissions'] ?? [];
            if (!in_array('file.download', $permissions) && !in_array('all', $permissions)) {
                // Log access denied
                logActivity('access_denied', 'download', $fileId, $file['name'], $user['id'], false, "Access denied: Insufficient permissions to download {$file['name']}", 'high');
                echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                exit;
            }

            // Increment download count
            $file['download_count'] = ($file['download_count'] ?? 0) + 1;
            $db->updateFile($fileId, $file);

            // Log successful download
            logActivity('file_download', 'download', $fileId, $file['name'], $user['id'], true, "File downloaded: {$file['name']}", 'low');

            // Read encrypted file from storage
            $filePath = $file['encrypted_path'] ?? ($file['file_path'] ?? ENCRYPTED_PATH . $fileId . '.enc');
            if (!file_exists($filePath)) {
                logActivity('file_access', 'download', $fileId, $file['name'], $user['id'], false, "File storage not found: {$file['name']}", 'high');
                echo json_encode(['success' => false, 'message' => 'File storage not found']);
                exit;
            }
            
            $encryptedContent = file_get_contents($filePath);
            
            // Check if user wants encrypted version
            $getEncrypted = isset($_POST['get_encrypted']) && $_POST['get_encrypted'] === 'true';
            
            if ($getEncrypted) {
                // Return encrypted content
                echo json_encode([
                    'success' => true,
                    'encrypted_content' => base64_encode($encryptedContent),
                    'file_name' => $file['name'] . '.enc'
                ]);
            } else {
                // Decrypt and return file
                $decryptedContent = decryptData($encryptedContent, ENCRYPTION_KEY);
                
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $file['name'] . '"');
                header('Content-Length: ' . strlen($decryptedContent));
                echo $decryptedContent;
            }
            exit;

        case 'list_files':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Get files from file database
            $allFiles = $db->getAllFiles();
            $userFiles = [];
            $permissions = $user['permissions'] ?? [];
            
            $isAdmin = in_array('all', $permissions) || ($user['role'] ?? '') === 'admin';
            
            foreach ($allFiles as $file) {
                // Check if user has access (owner or admin)
                if ($file['uploaded_by'] === $user['id'] || $isAdmin) {
                    // Get uploaded_at timestamp, with fallback to created_at
                    $uploadedAt = null;
                    if (isset($file['uploaded_at']) && $file['uploaded_at']) {
                        if (is_numeric($file['uploaded_at']) && $file['uploaded_at'] > 0) {
                            $uploadedAt = $file['uploaded_at'];
                        } else if (!is_numeric($file['uploaded_at'])) {
                            $uploadedAt = strtotime($file['uploaded_at']);
                            if ($uploadedAt === false || $uploadedAt < 0) {
                                $uploadedAt = null;
                            }
                        }
                    }
                    // If uploaded_at is invalid (0, null, or negative), try created_at
                    if (!$uploadedAt || $uploadedAt <= 0) {
                        if (isset($file['created_at']) && $file['created_at']) {
                            if (is_numeric($file['created_at']) && $file['created_at'] > 0) {
                                $uploadedAt = $file['created_at'];
                            } else if (!is_numeric($file['created_at'])) {
                                $uploadedAt = strtotime($file['created_at']);
                                if ($uploadedAt === false || $uploadedAt < 0) {
                                    $uploadedAt = null;
                                }
                            }
                        }
                    }
                    // Final fallback to current time if still invalid
                    if (!$uploadedAt || $uploadedAt <= 0) {
                        $uploadedAt = time();
                    }
                    
                    $fileData = [
                        'file_id' => $file['file_id'],
                        'name' => $file['name'] ?? 'Unknown',
                        'size' => $file['size'] ?? 0,
                        'uploaded_at' => $uploadedAt,
                        'expires_at' => isset($file['expires_at']) ? (is_numeric($file['expires_at']) ? $file['expires_at'] : strtotime($file['expires_at'])) : null,
                        'status' => $file['status'] ?? 'pending',
                        'encrypted' => $file['encrypted'] ?? false,
                        'shared_with' => $file['shared_with'] ?? []
                    ];
                    
                    // Add uploader information for admins
                    if ($isAdmin && isset($file['uploaded_by'])) {
                        $uploader = $db->getUserById($file['uploaded_by']);
                        if ($uploader) {
                            $fileData['uploaded_by'] = $file['uploaded_by'];
                            $fileData['uploader_email'] = $uploader['email'] ?? 'Unknown';
                            $fileData['uploader_name'] = trim(($uploader['first_name'] ?? '') . ' ' . ($uploader['last_name'] ?? ''));
                            if (empty($fileData['uploader_name'])) {
                                $fileData['uploader_name'] = $fileData['uploader_email'];
                            }
                        }
                    }
                    
                    $userFiles[] = $fileData;
                }
            }

            echo json_encode([
                'success' => true,
                'files' => $userFiles,
                'message' => 'Files retrieved successfully'
            ]);
            exit;

        case 'delete_file':
            require_once __DIR__ . '/config.php';
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $fileId = $_POST['file_id'] ?? '';
            $tokenData = validateToken($token);

            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Get file from database
            $file = $db->getFileById($fileId);
            if (!$file) {
                echo json_encode(['success' => false, 'message' => 'File not found']);
                exit;
            }

            // Check if user is admin or owns the file
            $permissions = $user['permissions'] ?? [];
            $isAdmin = in_array('all', $permissions) || ($user['role'] ?? '') === 'admin';
            if (!$isAdmin) {
                if ($file['uploaded_by'] !== $user['id']) {
                    echo json_encode(['success' => false, 'message' => 'Insufficient permissions. You can only delete your own files.']);
                    exit;
                }
            }

            // Delete file from storage (both original and encrypted if they exist)
            if (isset($file['file_path']) && file_exists($file['file_path'])) {
                @unlink($file['file_path']);
            }
            if (isset($file['encrypted_path']) && file_exists($file['encrypted_path'])) {
                @unlink($file['encrypted_path']);
            }
            // Fallback: try to delete from default encrypted path
            $defaultEncryptedPath = ENCRYPTED_PATH . $fileId . '.enc';
            if (file_exists($defaultEncryptedPath)) {
                @unlink($defaultEncryptedPath);
            }
            
            // Delete file from database
            $db->deleteFile($fileId);
            
            // Delete file shares if method exists
            try {
                $shares = $db->getFileShares($fileId);
                if (is_array($shares)) {
                    foreach ($shares as $share) {
                        if (isset($share['id']) && method_exists($db, 'deleteFileShare')) {
                            $db->deleteFileShare($share['id']);
                        }
                    }
                }
            } catch (Exception $e) {
                // Ignore errors with file shares
            }

            // Log deletion
            logActivity('file_management', 'delete', $fileId, $file['name'] ?? 'Unknown', $user['id'], true, "File deleted: " . ($file['name'] ?? 'Unknown'), 'low');

            echo json_encode([
                'success' => true,
                'message' => 'File deleted successfully'
            ]);
            exit;

        case 'update_file':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $fileId = $_POST['file_id'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Get file from database
            $file = $db->getFileById($fileId);
            if (!$file) {
                echo json_encode(['success' => false, 'message' => 'File not found']);
                exit;
            }

            // Check if user is admin or owns the file
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions)) {
                if ($file['uploaded_by'] !== $user['id']) {
                    echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                    exit;
                }
            }

            // Update file data
            if (isset($_POST['new_name'])) {
                $file['name'] = $_POST['new_name'];
            }
            if (isset($_POST['expiry_hours'])) {
                $expiryHours = intval($_POST['expiry_hours']);
                if ($expiryHours > 0) {
                    // When user edits expiry, calculate from NOW (current time)
                    // This makes sense - if they set 23 hours, they want it to expire 23 hours from now
                    $file['expires_at'] = time() + ($expiryHours * 3600);
                } else {
                    $file['expires_at'] = null;
                }
            }

            $db->updateFile($fileId, $file);

            echo json_encode([
                'success' => true,
                'message' => 'File updated successfully',
                'file_info' => [
                    'name' => $file['name'],
                    'expires_at' => $file['expires_at'] ? (is_numeric($file['expires_at']) ? $file['expires_at'] : strtotime($file['expires_at'])) : null
                ]
            ]);
            exit;

        case 'logout':
            session_destroy();
            echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
            exit;

        case 'get_activity_logs':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Get filters
            $riskLevel = $_POST['risk_level'] ?? 'all';
            $actionType = $_POST['action_type'] ?? 'all';
            $search = $_POST['search'] ?? '';
            $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 50;

            // Build filters for file database
            $filters = [
                'risk_level' => $riskLevel,
                'action_type' => $actionType,
                'limit' => $limit
            ];
            
            // Filter by user (non-admin users only see their own logs)
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions)) {
                $filters['user_id'] = $user['id'];
            }

            // Get logs from file database
            $allLogs = $db->getAuditLogs($filters);

            // Apply search filter
            if (!empty($search)) {
                $searchLower = strtolower($search);
                $allLogs = array_filter($allLogs, function($log) use ($searchLower) {
                    $fileName = strtolower($log['file_name'] ?? '');
                    $userEmail = strtolower($log['user_email'] ?? '');
                    $description = strtolower($log['description'] ?? '');
                    $action = strtolower($log['action'] ?? '');
                    
                    return strpos($fileName, $searchLower) !== false ||
                           strpos($userEmail, $searchLower) !== false ||
                           strpos($description, $searchLower) !== false ||
                           strpos($action, $searchLower) !== false;
                });
            }

            // Format logs for frontend
            $formattedLogs = [];
            foreach ($allLogs as $log) {
                // Ensure created_at exists
                if (!isset($log['created_at'])) {
                    $log['created_at'] = date('Y-m-d H:i:s');
                }
                
                // Convert to timestamp for accurate client-side parsing
                $timestamp = strtotime($log['created_at']);
                if ($timestamp !== false) {
                    // Send both the original string and timestamp for compatibility
                    $log['created_at'] = $log['created_at'];
                    $log['created_at_timestamp'] = $timestamp;
                }
                
                $formattedLogs[] = $log;
            }
            $logs = $formattedLogs;

            // Calculate statistics (get all logs for stats, respecting user filter)
            $statsFilters = [];
            if (!in_array('all', $permissions)) {
                $statsFilters['user_id'] = $user['id'];
            }
            $allLogsForStats = $db->getAuditLogs($statsFilters);
            
            $stats = [
                'total_events' => count($allLogsForStats),
                'downloads' => 0,
                'access_denied' => 0,
                'high_risk' => 0
            ];

            foreach ($allLogsForStats as $log) {
                $action = strtolower($log['action'] ?? '');
                $logRiskLevel = $log['risk_level'] ?? 'low';
                $success = $log['success'] ?? true;

                if ($action === 'download') {
                    $stats['downloads']++;
                }
                if (!$success || $logRiskLevel === 'high') {
                    $stats['access_denied']++;
                }
                if ($logRiskLevel === 'high') {
                    $stats['high_risk']++;
                }
            }

            echo json_encode([
                'success' => true,
                'logs' => $logs,
                'stats' => $stats,
                'message' => 'Activity logs retrieved successfully'
            ]);
            exit;

        case 'clear_activity_logs':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check permissions - only admins can clear all logs, users can clear their own
            $permissions = $user['permissions'] ?? [];
            $isAdmin = in_array('all', $permissions);
            
            try {
                if ($isAdmin) {
                    // Admin can clear all logs
                    $deletedCount = $db->deleteAuditLogs(null);
                    logActivity('activity_management', 'clear_all_logs', null, null, $user['id'], true, "Admin cleared all activity logs", 'medium');
                } else {
                    // Regular users can only clear their own logs
                    $deletedCount = $db->deleteAuditLogs($user['id']);
                    logActivity('activity_management', 'clear_own_logs', null, null, $user['id'], true, "User cleared their own activity logs", 'low');
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => "Successfully cleared {$deletedCount} activity log(s)",
                    'deleted_count' => $deletedCount
                ]);
            } catch (Exception $e) {
                error_log("Error clearing activity logs: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Failed to clear activity logs']);
            }
            exit;

        case 'list_users':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            if (empty($token)) {
                echo json_encode(['success' => false, 'message' => 'Token is required']);
                exit;
            }
            
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database to ensure permissions are current
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check if user is active
            if (isset($user['is_active']) && !$user['is_active']) {
                echo json_encode(['success' => false, 'message' => 'Account is inactive']);
                exit;
            }

            // Only admins can list users
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                exit;
            }

            // Get all users from file database
            try {
                $users = $db->getAllUsers();
                
                // Remove sensitive data
                foreach ($users as &$u) {
                    unset($u['password_hash']);
                }
                
                echo json_encode([
                    'success' => true,
                    'users' => $users
                ]);
            } catch (Exception $e) {
                error_log("Error listing users: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Failed to retrieve users']);
            }
            exit;

        case 'create_user':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Only admins can create users
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                exit;
            }

            $firstName = trim($_POST['first_name'] ?? '');
            $lastName = trim($_POST['last_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = $_POST['role'] ?? 'user';
            $isActive = isset($_POST['is_active']) && $_POST['is_active'] === '1';

            if (empty($firstName) || empty($lastName) || empty($email) || empty($password)) {
                echo json_encode(['success' => false, 'message' => 'All fields are required']);
                exit;
            }

            if (!in_array($role, ['admin', 'user', 'viewer'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid role']);
                exit;
            }

            try {
                // Check if email already exists
                $existingUser = $db->getUserByEmail($email);
                if ($existingUser) {
                    echo json_encode(['success' => false, 'message' => 'Email already exists']);
                    exit;
                }
                
                // Get permissions based on role
                $permissions = [];
                if ($role === 'admin') {
                    $permissions = ['all'];
                } elseif ($role === 'user') {
                    $permissions = ['file.upload', 'file.download', 'file.share'];
                } elseif ($role === 'viewer') {
                    $permissions = ['file.download'];
                }
                
                // Hash password
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                
                // Create user
                $userId = $db->createUser([
                    'email' => $email,
                    'password_hash' => $passwordHash,
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'role' => $role,
                    'is_active' => $isActive,
                    'permissions' => $permissions,
                    'two_factor_enabled' => false,
                    'failed_login_attempts' => 0
                ]);
                
                logActivity('user_management', 'create_user', null, null, $user['id'], true, "Admin created user: {$email}", 'low');
                
                echo json_encode([
                    'success' => true,
                    'message' => 'User created successfully',
                    'user_id' => $userId
                ]);
            } catch (Exception $e) {
                error_log("Error creating user: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Failed to create user']);
            }
            exit;

        case 'update_user':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Only admins can update users
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                exit;
            }

            $userId = $_POST['user_id'] ?? '';
            $firstName = trim($_POST['first_name'] ?? '');
            $lastName = trim($_POST['last_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = $_POST['role'] ?? 'user';
            $isActive = isset($_POST['is_active']) && $_POST['is_active'] === '1';

            if (empty($userId) || empty($firstName) || empty($lastName) || empty($email)) {
                echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
                exit;
            }

            if (!in_array($role, ['admin', 'user', 'viewer'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid role']);
                exit;
            }

            try {
                // Get existing user
                $existingUser = $db->getUserById($userId);
                if (!$existingUser) {
                    echo json_encode(['success' => false, 'message' => 'User not found']);
                    exit;
                }
                
                // Check if email is being changed and if it already exists
                if ($existingUser['email'] !== $email) {
                    $emailUser = $db->getUserByEmail($email);
                    if ($emailUser && $emailUser['id'] !== $userId) {
                        echo json_encode(['success' => false, 'message' => 'Email already exists']);
                        exit;
                    }
                }
                
                // Get permissions based on role
                $permissions = [];
                if ($role === 'admin') {
                    $permissions = ['all'];
                } elseif ($role === 'user') {
                    $permissions = ['file.upload', 'file.download', 'file.share'];
                } elseif ($role === 'viewer') {
                    $permissions = ['file.download'];
                }
                
                // Prepare update data
                $updateData = [
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'email' => $email,
                    'role' => $role,
                    'is_active' => $isActive,
                    'permissions' => $permissions
                ];
                
                // Update password if provided
                if (!empty($password)) {
                    $updateData['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
                } else {
                    $updateData['password_hash'] = $existingUser['password_hash'];
                }
                
                // Preserve other fields
                $updateData['two_factor_enabled'] = $existingUser['two_factor_enabled'] ?? false;
                $updateData['failed_login_attempts'] = $existingUser['failed_login_attempts'] ?? 0;
                $updateData['last_login'] = $existingUser['last_login'] ?? null;
                
                // Update user
                $db->updateUser($userId, $updateData);
                
                logActivity('user_management', 'update_user', null, null, $user['id'], true, "Admin updated user: {$email}", 'low');
                
                echo json_encode([
                    'success' => true,
                    'message' => 'User updated successfully'
                ]);
            } catch (Exception $e) {
                error_log("Error updating user: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Failed to update user']);
            }
            exit;

        case 'delete_user':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }

            // Only admins can delete users
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
                exit;
            }

            $userId = $_POST['user_id'] ?? '';

            if (empty($userId)) {
                echo json_encode(['success' => false, 'message' => 'User ID is required']);
                exit;
            }

            // Prevent deleting yourself
            if ($userId === $user['id']) {
                echo json_encode(['success' => false, 'message' => 'You cannot delete your own account']);
                exit;
            }

            try {
                // Get user email for logging
                $targetUser = $db->getUserById($userId);
                
                if (!$targetUser) {
                    echo json_encode(['success' => false, 'message' => 'User not found']);
                    exit;
                }
                
                $userEmail = $targetUser['email'] ?? 'Unknown';
                
                // Delete user
                $db->deleteUser($userId);
                
                logActivity('user_management', 'delete_user', null, null, $user['id'], true, "Admin deleted user: {$userEmail}", 'high');
                
                echo json_encode([
                    'success' => true,
                    'message' => 'User deleted successfully'
                ]);
            } catch (Exception $e) {
                error_log("Error deleting user: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
            }
            exit;

        case 'list_pending_files':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check if user is admin
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Admin access required']);
                exit;
            }
            
            // Get all pending files
            $allFiles = $db->getAllFiles();
            $pendingFiles = [];
            
            foreach ($allFiles as $file) {
                $status = $file['status'] ?? 'pending';
                // Only show pending files (not revoked or ready)
                if ($status === 'pending' && (!isset($file['revoked']) || !$file['revoked'])) {
                    // Get uploader info
                    $uploader = $db->getUserById($file['uploaded_by']);
                    $pendingFiles[] = [
                        'file_id' => $file['file_id'],
                        'name' => $file['name'] ?? 'Unknown',
                        'size' => $file['size'] ?? 0,
                        'uploaded_at' => isset($file['uploaded_at']) ? (is_numeric($file['uploaded_at']) ? $file['uploaded_at'] : strtotime($file['uploaded_at'])) : time(),
                        'uploaded_by' => $file['uploaded_by'],
                        'uploader_email' => $uploader['email'] ?? 'Unknown',
                        'uploader_name' => ($uploader['first_name'] ?? '') . ' ' . ($uploader['last_name'] ?? ''),
                    ];
                }
            }
            
            // Sort by upload time (newest first)
            usort($pendingFiles, function($a, $b) {
                return $b['uploaded_at'] - $a['uploaded_at'];
            });
            
            echo json_encode([
                'success' => true,
                'files' => $pendingFiles,
                'message' => 'Pending files retrieved successfully'
            ]);
            exit;

        case 'list_expired_files':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check if user is admin
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Admin access required']);
                exit;
            }
            
            // Get all files
            $allFiles = $db->getAllFiles();
            $expiredFiles = [];
            $now = time();
            
            foreach ($allFiles as $file) {
                $status = $file['status'] ?? 'pending';
                // Skip revoked files
                if ($status === 'revoked' || (isset($file['revoked']) && $file['revoked'])) {
                    continue;
                }
                
                // Check if file has expired
                if (isset($file['expires_at']) && $file['expires_at']) {
                    $expiresAt = is_numeric($file['expires_at']) ? $file['expires_at'] : strtotime($file['expires_at']);
                    if ($expiresAt && $expiresAt < $now) {
                        // Get uploader info
                        $uploader = $db->getUserById($file['uploaded_by']);
                        $expiredFiles[] = [
                            'file_id' => $file['file_id'],
                            'name' => $file['name'] ?? 'Unknown',
                            'size' => $file['size'] ?? 0,
                            'uploaded_at' => isset($file['uploaded_at']) ? (is_numeric($file['uploaded_at']) ? $file['uploaded_at'] : strtotime($file['uploaded_at'])) : time(),
                            'expires_at' => $expiresAt,
                            'uploaded_by' => $file['uploaded_by'],
                            'uploader_email' => $uploader['email'] ?? 'Unknown',
                            'uploader_name' => ($uploader['first_name'] ?? '') . ' ' . ($uploader['last_name'] ?? ''),
                        ];
                    }
                }
            }
            
            // Sort by expiry time (most recently expired first)
            usort($expiredFiles, function($a, $b) {
                return $b['expires_at'] - $a['expires_at'];
            });
            
            echo json_encode([
                'success' => true,
                'files' => $expiredFiles,
                'message' => 'Expired files retrieved successfully'
            ]);
            exit;
            
        case 'accept_file':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $fileId = $_POST['file_id'] ?? '';
            $newName = $_POST['new_name'] ?? '';
            $expiryHours = isset($_POST['expiry_hours']) ? intval($_POST['expiry_hours']) : 24;
            
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check if user is admin
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Admin access required']);
                exit;
            }
            
            // Get file from database
            $file = $db->getFileById($fileId);
            if (!$file) {
                echo json_encode(['success' => false, 'message' => 'File not found']);
                exit;
            }
            
            // Check if file is pending
            $status = $file['status'] ?? 'pending';
            if ($status !== 'pending') {
                echo json_encode(['success' => false, 'message' => 'File is not pending']);
                exit;
            }
            
            // Validate inputs
            if (empty($newName)) {
                echo json_encode(['success' => false, 'message' => 'File name is required']);
                exit;
            }
            
            if ($expiryHours < 1) {
                echo json_encode(['success' => false, 'message' => 'Expiry must be at least 1 hour']);
                exit;
            }
            
            // Read original file
            $originalPath = $file['file_path'];
            if (!file_exists($originalPath)) {
                echo json_encode(['success' => false, 'message' => 'Original file not found']);
                exit;
            }
            
            $fileContent = file_get_contents($originalPath);
            
            // Encrypt file
            $encryptedContent = encryptData($fileContent, ENCRYPTION_KEY);
            
            // Save encrypted file
            $encryptedPath = ENCRYPTED_PATH;
            if (!file_exists($encryptedPath)) {
                mkdir($encryptedPath, 0755, true);
            }
            $encryptedFilePath = $encryptedPath . $fileId . '.enc';
            file_put_contents($encryptedFilePath, $encryptedContent);
            
            // Calculate expiry time (from now)
            $expiresAt = time() + ($expiryHours * 3600);
            
            // Update file metadata
            $file['name'] = $newName;
            $file['encrypted'] = true;
            $file['status'] = 'ready';
            $file['encrypted_path'] = $encryptedFilePath;
            $file['encrypted_at'] = time();
            $file['encrypted_by'] = $user['id'];
            $file['expires_at'] = $expiresAt;
            $db->updateFile($fileId, $file);
            
            // Delete original unencrypted file
            if (file_exists($originalPath)) {
                unlink($originalPath);
            }
            
            // Log acceptance activity
            logActivity('file_acceptance', 'accept', $fileId, $newName, $user['id'], true, "Admin accepted and encrypted file: {$newName}", 'low');
            
            echo json_encode([
                'success' => true,
                'message' => 'File accepted and encrypted successfully',
                'file_info' => [
                    'file_id' => $fileId,
                    'name' => $newName,
                    'status' => 'ready',
                    'expires_at' => $expiresAt
                ]
            ]);
            exit;

        case 'revoke_file':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $fileId = $_POST['file_id'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check if user is admin
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Admin access required']);
                exit;
            }
            
            // Get file from database
            $file = $db->getFileById($fileId);
            if (!$file) {
                echo json_encode(['success' => false, 'message' => 'File not found']);
                exit;
            }
            
            // Check if file is pending
            $status = $file['status'] ?? 'pending';
            if ($status !== 'pending') {
                echo json_encode(['success' => false, 'message' => 'Only pending files can be revoked']);
                exit;
            }
            
            // Update file status to revoked
            $file['status'] = 'revoked';
            $file['revoked'] = true;
            $file['revoked_at'] = time();
            $file['revoked_by'] = $user['id'];
            $db->updateFile($fileId, $file);
            
            // Delete original file from storage
            if (isset($file['file_path']) && file_exists($file['file_path'])) {
                unlink($file['file_path']);
            }
            
            // Log revocation activity
            logActivity('file_revocation', 'revoke', $fileId, $file['name'], $user['id'], true, "Admin revoked file: {$file['name']}", 'medium');
            
            echo json_encode([
                'success' => true,
                'message' => 'File revoked successfully',
                'file_info' => [
                    'file_id' => $fileId,
                    'name' => $file['name'],
                    'status' => 'revoked'
                ]
            ]);
            exit;

        case 'encrypt_file':
            $db = getDatabase();
            
            $token = $_POST['token'] ?? '';
            $fileId = $_POST['file_id'] ?? '';
            $tokenData = validateToken($token);
            if (!$tokenData) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Get full user data from database
            $user = $db->getUserById($tokenData['user_id']);
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit;
            }
            
            // Check if user is admin
            $permissions = $user['permissions'] ?? [];
            if (!in_array('all', $permissions) && $user['role'] !== 'admin') {
                echo json_encode(['success' => false, 'message' => 'Admin access required']);
                exit;
            }
            
            // Get file from database
            $file = $db->getFileById($fileId);
            if (!$file) {
                echo json_encode(['success' => false, 'message' => 'File not found']);
                exit;
            }
            
            // Check if file is pending
            $status = $file['status'] ?? 'pending';
            if ($status !== 'pending') {
                echo json_encode(['success' => false, 'message' => 'File is not pending encryption']);
                exit;
            }
            
            // Read original file
            $originalPath = $file['file_path'];
            if (!file_exists($originalPath)) {
                echo json_encode(['success' => false, 'message' => 'Original file not found']);
                exit;
            }
            
            $fileContent = file_get_contents($originalPath);
            
            // Encrypt file
            $encryptedContent = encryptData($fileContent, ENCRYPTION_KEY);
            
            // Save encrypted file
            $encryptedPath = ENCRYPTED_PATH;
            if (!file_exists($encryptedPath)) {
                mkdir($encryptedPath, 0755, true);
            }
            $encryptedFilePath = $encryptedPath . $fileId . '.enc';
            file_put_contents($encryptedFilePath, $encryptedContent);
            
            // Update file metadata
            $file['encrypted'] = true;
            $file['status'] = 'ready';
            $file['encrypted_path'] = $encryptedFilePath;
            $file['encrypted_at'] = time();
            $file['encrypted_by'] = $user['id'];
            $db->updateFile($fileId, $file);
            
            // Delete original unencrypted file
            if (file_exists($originalPath)) {
                unlink($originalPath);
            }
            
            // Log encryption activity
            logActivity('file_encryption', 'encrypt', $fileId, $file['name'], $user['id'], true, "Admin encrypted file: {$file['name']}", 'low');
            
            echo json_encode([
                'success' => true,
                'message' => 'File encrypted successfully',
                'file_info' => [
                    'file_id' => $fileId,
                    'name' => $file['name'],
                    'status' => 'ready'
                ]
            ]);
            exit;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            exit;
    }
} else {
    // Log what we received for debugging
    error_log('API Request - Method: ' . $_SERVER['REQUEST_METHOD'] . ', POST data: ' . print_r($_POST, true));
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid request method or missing action',
        'debug' => [
            'method' => $_SERVER['REQUEST_METHOD'],
            'has_post' => !empty($_POST),
            'post_keys' => array_keys($_POST)
        ]
    ]);
}
?>


