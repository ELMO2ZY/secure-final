<?php
/**
 * Configuration file - Loads environment variables and provides database connection
 */

// Load environment variables from .env file if it exists
if (file_exists(__DIR__ . '/.env')) {
    $lines = file(__DIR__ . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue; // Skip comments
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value);
        }
    }
}

// Database configuration
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'secure_file_share');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');
define('DB_CHARSET', 'utf8mb4');

// JWT Configuration - Use persistent secret file
$jwtSecretFile = __DIR__ . '/db/.jwt_secret';
if (file_exists($jwtSecretFile)) {
    $jwtSecret = trim(file_get_contents($jwtSecretFile));
} else {
    $jwtSecret = bin2hex(random_bytes(32));
    if (!file_exists(__DIR__ . '/db')) {
        mkdir(__DIR__ . '/db', 0755, true);
    }
    file_put_contents($jwtSecretFile, $jwtSecret);
}
define('JWT_SECRET', $_ENV['JWT_SECRET'] ?? $jwtSecret);
define('JWT_EXPIRY', intval($_ENV['JWT_EXPIRY'] ?? 3600));

// Encryption Configuration - Use persistent key file
$encryptionKeyFile = __DIR__ . '/db/.encryption_key';
if (file_exists($encryptionKeyFile)) {
    $encryptionKey = trim(file_get_contents($encryptionKeyFile));
} else {
    $encryptionKey = bin2hex(random_bytes(16));
    if (!file_exists(__DIR__ . '/db')) {
        mkdir(__DIR__ . '/db', 0755, true);
    }
    file_put_contents($encryptionKeyFile, $encryptionKey);
}
define('ENCRYPTION_KEY', $_ENV['ENCRYPTION_KEY'] ?? $encryptionKey);

// File Storage Paths
define('UPLOAD_PATH', $_ENV['UPLOAD_PATH'] ?? __DIR__ . '/storage/uploads/');
define('ENCRYPTED_PATH', $_ENV['ENCRYPTED_PATH'] ?? __DIR__ . '/storage/encrypted/');

// Security Settings
define('MAX_FILE_SIZE', intval($_ENV['MAX_FILE_SIZE'] ?? 104857600)); // 100MB
define('SESSION_TIMEOUT', intval($_ENV['SESSION_TIMEOUT'] ?? 1800));
define('MAX_LOGIN_ATTEMPTS', intval($_ENV['MAX_LOGIN_ATTEMPTS'] ?? 5));

/**
 * Get database connection (File-based database)
 */
function getDatabase() {
    static $db = null;
    
    if ($db === null) {
        require_once __DIR__ . '/db/FileDatabase.php';
        require_once __DIR__ . '/db/init.php';
        $db = FileDatabase::getInstance();
    }
    
    return $db;
}

/**
 * Ensure storage directories exist
 */
function ensureStorageDirectories() {
    $directories = [UPLOAD_PATH, ENCRYPTED_PATH];
    foreach ($directories as $dir) {
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

// Initialize storage directories
ensureStorageDirectories();

