<?php
/**
 * File-Based Database System
 * Stores all data in JSON files within the db/ directory
 */

class FileDatabase {
    private static $instance = null;
    private $dbPath;
    
    private function __construct() {
        $this->dbPath = __DIR__;
        $this->ensureDirectories();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function ensureDirectories() {
        $dirs = [
            $this->dbPath . '/users',
            $this->dbPath . '/files',
            $this->dbPath . '/sessions',
            $this->dbPath . '/audit_logs',
            $this->dbPath . '/file_shares'
        ];
        
        foreach ($dirs as $dir) {
            if (!file_exists($dir)) {
                mkdir($dir, 0755, true);
            }
        }
    }
    
    // Generic file operations
    private function readFile($file) {
        if (!file_exists($file)) {
            return [];
        }
        $content = file_get_contents($file);
        return json_decode($content, true) ?: [];
    }
    
    private function writeFile($file, $data) {
        $dir = dirname($file);
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    
    private function getFilePath($table, $id = null) {
        if ($id) {
            return $this->dbPath . "/{$table}/{$id}.json";
        }
        return $this->dbPath . "/{$table}.json";
    }
    
    // User operations
    public function getUserById($id) {
        $file = $this->getFilePath('users', $id);
        return $this->readFile($file);
    }
    
    public function getUserByEmail($email) {
        $users = $this->getAllUsers();
        foreach ($users as $user) {
            if (isset($user['email']) && $user['email'] === $email) {
                return $user;
            }
        }
        return null;
    }
    
    public function getAllUsers() {
        $usersDir = $this->dbPath . '/users';
        $users = [];
        
        if (file_exists($usersDir)) {
            $files = glob($usersDir . '/*.json');
            foreach ($files as $file) {
                $user = $this->readFile($file);
                if (!empty($user)) {
                    $users[] = $user;
                }
            }
        }
        
        return $users;
    }
    
    public function createUser($userData) {
        $id = $userData['id'] ?? bin2hex(random_bytes(16));
        $userData['id'] = $id;
        $userData['created_at'] = date('Y-m-d H:i:s');
        $userData['updated_at'] = date('Y-m-d H:i:s');
        
        $file = $this->getFilePath('users', $id);
        $this->writeFile($file, $userData);
        
        return $id;
    }
    
    public function updateUser($id, $userData) {
        $user = $this->getUserById($id);
        if (!$user) {
            return false;
        }
        
        $userData['id'] = $id;
        $userData['created_at'] = $user['created_at'] ?? date('Y-m-d H:i:s');
        $userData['updated_at'] = date('Y-m-d H:i:s');
        
        $file = $this->getFilePath('users', $id);
        $this->writeFile($file, $userData);
        
        return true;
    }
    
    public function deleteUser($id) {
        $file = $this->getFilePath('users', $id);
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }
    
    // File operations
    public function getFileById($id) {
        $file = $this->getFilePath('files', $id);
        return $this->readFile($file);
    }
    
    public function getAllFiles($userId = null) {
        $filesDir = $this->dbPath . '/files';
        $files = [];
        
        if (file_exists($filesDir)) {
            $fileList = glob($filesDir . '/*.json');
            foreach ($fileList as $filePath) {
                $file = $this->readFile($filePath);
                if (!empty($file)) {
                    if ($userId === null || (isset($file['uploaded_by']) && $file['uploaded_by'] === $userId)) {
                        $files[] = $file;
                    }
                }
            }
        }
        
        return $files;
    }
    
    public function createFile($fileData) {
        $id = $fileData['file_id'] ?? bin2hex(random_bytes(16));
        $fileData['file_id'] = $id;
        // Only set uploaded_at if not already provided
        if (!isset($fileData['uploaded_at'])) {
            $fileData['uploaded_at'] = time();
        }
        $fileData['created_at'] = date('Y-m-d H:i:s');
        // Ensure status is set (default to pending if not provided)
        if (!isset($fileData['status'])) {
            $fileData['status'] = 'pending';
        }
        
        $file = $this->getFilePath('files', $id);
        $this->writeFile($file, $fileData);
        
        return $id;
    }
    
    public function updateFile($id, $fileData) {
        $file = $this->getFileById($id);
        if (!$file) {
            return false;
        }
        
        $fileData['file_id'] = $id;
        $fileData['uploaded_at'] = $file['uploaded_at'] ?? time();
        $fileData['created_at'] = $file['created_at'] ?? date('Y-m-d H:i:s');
        
        $filePath = $this->getFilePath('files', $id);
        $this->writeFile($filePath, $fileData);
        
        return true;
    }
    
    public function deleteFile($id) {
        $file = $this->getFilePath('files', $id);
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }
    
    // Session operations
    public function getSession($sessionId) {
        $file = $this->getFilePath('sessions', $sessionId);
        $session = $this->readFile($file);
        
        if ($session && isset($session['expires_at'])) {
            if (strtotime($session['expires_at']) < time()) {
                $this->deleteSession($sessionId);
                return null;
            }
        }
        
        return $session;
    }
    
    public function createSession($sessionData) {
        $sessionId = $sessionData['session_id'] ?? bin2hex(random_bytes(32));
        $sessionData['session_id'] = $sessionId;
        $sessionData['created_at'] = date('Y-m-d H:i:s');
        
        if (!isset($sessionData['expires_at'])) {
            $sessionData['expires_at'] = date('Y-m-d H:i:s', time() + 3600);
        }
        
        $file = $this->getFilePath('sessions', $sessionId);
        $this->writeFile($file, $sessionData);
        
        return $sessionId;
    }
    
    public function deleteSession($sessionId) {
        $file = $this->getFilePath('sessions', $sessionId);
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }
    
    public function deleteExpiredSessions() {
        $sessionsDir = $this->dbPath . '/sessions';
        if (!file_exists($sessionsDir)) {
            return;
        }
        
        $files = glob($sessionsDir . '/*.json');
        foreach ($files as $file) {
            $session = $this->readFile($file);
            if ($session && isset($session['expires_at'])) {
                if (strtotime($session['expires_at']) < time()) {
                    unlink($file);
                }
            }
        }
    }
    
    // Audit log operations
    public function createAuditLog($logData) {
        $id = bin2hex(random_bytes(16));
        $logData['id'] = $id;
        $logData['created_at'] = date('Y-m-d H:i:s');
        
        $file = $this->getFilePath('audit_logs', $id);
        $this->writeFile($file, $logData);
        
        return $id;
    }
    
    public function getAuditLogs($filters = []) {
        $logsDir = $this->dbPath . '/audit_logs';
        $logs = [];
        
        if (file_exists($logsDir)) {
            $files = glob($logsDir . '/*.json');
            foreach ($files as $file) {
                $log = $this->readFile($file);
                if (!empty($log)) {
                    // Apply filters
                    $include = true;
                    if (isset($filters['user_id']) && (!isset($log['user_id']) || $log['user_id'] !== $filters['user_id'])) {
                        $include = false;
                    }
                    if (isset($filters['risk_level']) && $filters['risk_level'] !== 'all' && 
                        (!isset($log['risk_level']) || $log['risk_level'] !== $filters['risk_level'])) {
                        $include = false;
                    }
                    if (isset($filters['action_type']) && $filters['action_type'] !== 'all' && 
                        (!isset($log['action']) || $log['action'] !== $filters['action_type'])) {
                        $include = false;
                    }
                    
                    if ($include) {
                        $logs[] = $log;
                    }
                }
            }
        }
        
        // Sort by created_at descending
        usort($logs, function($a, $b) {
            $timeA = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
            $timeB = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
            return $timeB - $timeA;
        });
        
        // Apply limit
        if (isset($filters['limit'])) {
            $logs = array_slice($logs, 0, intval($filters['limit']));
        }
        
        return $logs;
    }
    
    public function deleteAuditLogs($userId = null) {
        $logsDir = $this->dbPath . '/audit_logs';
        $deletedCount = 0;
        
        if (file_exists($logsDir)) {
            $files = glob($logsDir . '/*.json');
            foreach ($files as $file) {
                $log = $this->readFile($file);
                if (!empty($log)) {
                    // If userId is provided, only delete logs for that user
                    // If userId is null, delete all logs (admin only)
                    if ($userId === null || (isset($log['user_id']) && $log['user_id'] === $userId)) {
                        if (@unlink($file)) {
                            $deletedCount++;
                        }
                    }
                }
            }
        }
        
        return $deletedCount;
    }
    
    // File share operations
    public function createFileShare($shareData) {
        $id = bin2hex(random_bytes(16));
        $shareData['id'] = $id;
        $shareData['created_at'] = date('Y-m-d H:i:s');
        
        $file = $this->getFilePath('file_shares', $id);
        $this->writeFile($file, $shareData);
        
        return $id;
    }
    
    public function getFileShares($fileId = null, $userId = null) {
        $sharesDir = $this->dbPath . '/file_shares';
        $shares = [];
        
        if (file_exists($sharesDir)) {
            $files = glob($sharesDir . '/*.json');
            foreach ($files as $file) {
                $share = $this->readFile($file);
                if (!empty($share)) {
                    $include = true;
                    if ($fileId && (!isset($share['file_id']) || $share['file_id'] !== $fileId)) {
                        $include = false;
                    }
                    if ($userId && (!isset($share['shared_with']) || $share['shared_with'] !== $userId)) {
                        $include = false;
                    }
                    if ($include) {
                        $shares[] = $share;
                    }
                }
            }
        }
        
        return $shares;
    }
    
    public function deleteFileShare($id) {
        $file = $this->getFilePath('file_shares', $id);
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }
    
    // Helper method for compatibility with PDO-style queries
    public function query($sql, $params = []) {
        // This is a compatibility layer - file database doesn't use SQL
        // But we can parse simple queries for migration purposes
        return new FileDatabaseResult([]);
    }
}

// Compatibility class for PDO-style results
class FileDatabaseResult {
    private $data;
    private $position = 0;
    
    public function __construct($data) {
        $this->data = $data;
    }
    
    public function fetch($mode = PDO::FETCH_ASSOC) {
        if ($this->position >= count($this->data)) {
            return false;
        }
        return $this->data[$this->position++];
    }
    
    public function fetchAll($mode = PDO::FETCH_ASSOC) {
        return $this->data;
    }
    
    public function fetchColumn($column = 0) {
        $row = $this->fetch();
        if ($row === false) {
            return false;
        }
        if (is_array($row)) {
            $values = array_values($row);
            return $values[$column] ?? false;
        }
        return false;
    }
    
    public function rowCount() {
        return count($this->data);
    }
}


