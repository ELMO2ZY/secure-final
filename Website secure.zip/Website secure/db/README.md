# File-Based Database System

This is a standalone file-based database system that stores all data in JSON files within the `db/` directory. No MySQL or external database server is required.

## Structure

```
db/
├── FileDatabase.php    # Main database class
├── init.php            # Initialization script
├── users/              # User data (one JSON file per user)
├── files/              # File metadata (one JSON file per file)
├── sessions/           # User sessions
├── audit_logs/         # Activity/audit logs
└── file_shares/        # File sharing records
```

## Features

- **No Database Server Required**: All data stored in JSON files
- **Automatic Initialization**: Creates default users on first run
- **Simple Structure**: Easy to backup, migrate, or inspect
- **Thread-Safe**: File locking prevents data corruption
- **Compatible API**: Works as drop-in replacement for MySQL

## Default Users

On first initialization, the system creates:

1. **Admin User**
   - Email: `admin@securefileshare.com`
   - Password: `admin123`
   - Role: Admin (all permissions)

2. **Regular User**
   - Email: `user@securefileshare.com`
   - Password: `user123`
   - Role: User (upload, download, share)

3. **Viewer User**
   - Email: `viewer@securefileshare.com`
   - Password: `viewer123`
   - Role: Viewer (download only)

## Backup

To backup the database, simply copy the entire `db/` directory:

```bash
cp -r db/ db_backup_$(date +%Y%m%d)/
```

## Migration from MySQL

If you have existing MySQL data, you can export it and convert to JSON format. The file structure matches the database schema.

## Security Notes

- All passwords are hashed using `password_hash()` (bcrypt)
- File permissions are set to 0755 (readable by owner/group)
- Sensitive data is never stored in plain text
- Each user/file has its own JSON file for isolation





