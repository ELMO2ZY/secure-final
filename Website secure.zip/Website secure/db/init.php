<?php
/**
 * Initialize File Database
 * Creates initial data if database is empty
 */

require_once __DIR__ . '/FileDatabase.php';

function initializeDatabase() {
    $db = FileDatabase::getInstance();
    
    // Check if database is already initialized
    $users = $db->getAllUsers();
    if (count($users) > 0) {
        return; // Database already has data
    }
    
    // Create default admin user
    $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $db->createUser([
        'id' => 'admin_001',
        'email' => 'admin@securefileshare.com',
        'password_hash' => $adminPassword,
        'first_name' => 'Admin',
        'last_name' => 'User',
        'role' => 'admin',
        'is_active' => true,
        'two_factor_enabled' => false,
        'failed_login_attempts' => 0,
        'permissions' => ['all']
    ]);
    
    // Create default regular user
    $userPassword = password_hash('user123', PASSWORD_DEFAULT);
    $db->createUser([
        'id' => 'user_001',
        'email' => 'user@securefileshare.com',
        'password_hash' => $userPassword,
        'first_name' => 'Test',
        'last_name' => 'User',
        'role' => 'user',
        'is_active' => true,
        'two_factor_enabled' => false,
        'failed_login_attempts' => 0,
        'permissions' => ['file.upload', 'file.download', 'file.share']
    ]);
    
    // Create default viewer user
    $viewerPassword = password_hash('viewer123', PASSWORD_DEFAULT);
    $db->createUser([
        'id' => 'viewer_001',
        'email' => 'viewer@securefileshare.com',
        'password_hash' => $viewerPassword,
        'first_name' => 'Test',
        'last_name' => 'Viewer',
        'role' => 'viewer',
        'is_active' => true,
        'two_factor_enabled' => false,
        'failed_login_attempts' => 0,
        'permissions' => ['file.download']
    ]);
    
    // Create initial audit log
    $db->createAuditLog([
        'event_type' => 'system',
        'user_id' => 'admin_001',
        'action' => 'init',
        'success' => true,
        'description' => 'Database initialized',
        'ip_address' => '127.0.0.1',
        'risk_level' => 'low'
    ]);
}

// Auto-initialize on include
initializeDatabase();





