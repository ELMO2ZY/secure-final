<?php
// Redirect to frontend
header('Location: index.html');
exit;
?>